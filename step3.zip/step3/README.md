# Step3

### Version number
72cf4fe47f85c39779267d0ecee07655a354e623

### Files

- index.html -- the HTML file
- style.css -- css style file
- test.js -- provide test functionality; show result in browser console
- script.js -- provide action functionality

### Plugins
No Plugins. Only plain HTML, CSS, and javascript.

### Usage
- drag index.html into browser
- in the beginning, see an automatic test result in the browser console
- open _debugging terminal_, check the test result in the console
- add quantity on the left side screen, click **Add** button, and then see the result on the right side of the screen
- click **Test** button any time, and then check the test result in the browser console
- test 4 requirements -- 1. should have 2 Dove Soaps 2. should have 2 Axe Deos 3. total sales tax amount should be 35.00 4. total price should equal 314.96
