# Step2

### Version number
72cf4fe47f85c39779267d0ecee07655a354e623

### Files

- index.html -- the HTML file
- style.css -- css style file
- test.js -- provide test functionality; show result in browser console
- script.js -- provide action functionality

### Plugins
No Plugins. Only plain HTML, CSS, and javascript.

### Usage
- drag index.html into browser
- the init value is based on quantity 5
- in the beginning, see an automatic test result in the browser console
- open _debugging terminal_, check the test result in the console
- add quantity on the left side screen, click **Add** button, and then see the result on the right side of the screen
- click **Test** button any time, and then check the test result in the browser console
- when added 8 items, and then click **Test** button, the successful test result messages would be displayed in the browser console
