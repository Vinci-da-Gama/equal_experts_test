/**
 * This is the fixture object.
 */
const fixture = {
  qty: 5,
  total: 199.95,
};

/**
 * This is the error message object.
 */
const errorMessage = {
  qty: "Quantity is not 5.",
  total: "Total price is not 199.95.",
};

(() => {
  /**
   * In the beginning, do the test automatically.
   */
  test();
})();

/**
 * According to the scenario,
 * test the quantity should be 5, and the total price should be 199.95.
 */
function test() {
  it("should have 5 Dove Soaps", function () {
    assert(
      Number(document.querySelector(".product-qty").textContent) ===
        fixture.qty,
      errorMessage.qty
    );
  });
  it("should have total price 199.95", function () {
    assert(
      Number(document.querySelector(".product-totalprice").textContent) ===
        fixture.total,
      errorMessage.total
    );
  });
}

/**
 * @param {string} desc -- text description
 * @param {function} fn -- the test function
 * Use try-catch block to simulate test function.
 */
function it(desc, fn) {
  try {
    fn();
    console.log("\x1b[32m%s\x1b[0m", "\u2714 " + desc);
  } catch (error) {
    console.log("\n");
    console.log("\x1b[31m%s\x1b[0m", "\u2718 " + desc);
    console.error(error);
  }
}

/**
 * @param {boolean} isTrue -- condition boolean
 * @param {string} msg -- text error message
 * Assert the result; if it is wrong, throw an error with an error message.
 */
function assert(isTrue, msg) {
  if (!isTrue) {
    throw new Error(msg);
  }
}
