/**
 * @param {string} qtyId -- user inputed quantity
 * This function will check the user inputed quantity of Dove Soap.
 * If the quantity is a positive integer, then enable Add button.
 * If the quantity is not a positive integer, then disable Add button.
 */
function checkQty(qtyId) {
  if (qtyId && qtyId.length > 0) {
    const elem = document.getElementById(qtyId);
    const btn = elem.nextElementSibling;
    !isNaN(elem.value) && elem.value > 0 && !elem.value.toString().includes(".")
      ? (btn.disabled = false)
      : (btn.disabled = true);
  } else {
    btn.disabled = true;
  }
}

/**
 * @param {string} qtyId -- user inputed quantity
 * @param {string} prodQty -- cart item quantity
 * @param {string} prodPrice -- cart item total price
 * Get user inputted quantity to calculate the total price, and then insert the values
 * to the quantity and total price fields in the cart panel.
 */
function addProducts(qtyId, prodQty, prodPrice) {
  const selectedQty = parseInt(document.getElementById(qtyId).value);
  const tp = (selectedQty * 39.99).toFixed(2);
  const cartList = document.getElementsByClassName("cart-item");
  for (let idx = 0; idx < cartList.length; idx++) {
    const elem = cartList[idx];
    switch (elem.innerText.split(" ")[0]) {
      case "Dove":
        elem.getElementsByClassName(prodQty)[0].innerHTML = selectedQty;
        elem.getElementsByClassName(prodPrice)[0].innerHTML = tp;
        break;
      default:
        break;
    }
  }
}
